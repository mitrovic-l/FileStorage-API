package commandLine;

import specifikacija.FileStorageSpecification;
import specifikacija.SpecificationManager;
import specifikacija.izuzeci.*;

import java.util.List;
import java.util.Scanner;



public class Main {

    static void ispis(List<String> files){
        for (String s : files)
            System.out.println(s);
    }
    public static void main(String[] args) throws ClassNotFoundException, InvalidExtension, DuplicateName, NoSuchFile, InvalidDelete, OversizeException {
        //  Class.forName("implementation.LocalImplementation");
        //Class.forName("implementation.DriveImplementation");
        FileStorageSpecification local;
        boolean loaded = false;
        while (true) {
            Scanner sc = new Scanner(System.in);
            if (!loaded){
                System.out.println("Izaberite tip storage-a [Lokal ili Remote]: ");
                String st = sc.nextLine();
                switch (st){
                    case "local":
                        Class.forName("implementation.LocalImplementation");
                        loaded = true;
                        System.out.println("Izabran local storage");
                    break;
                    case "remote":
                        Class.forName("implementation.DriveImplementation");
                        loaded = true;
                        System.out.println("Izabran remote storage");
                        break;
                    default:
                        System.out.println("Pogresno unesena komanda, pokusajte ponovo.");
                        break;
                }

            }
            local = SpecificationManager.getImplementation();
            String line = sc.nextLine();
           // System.out.println("Uneli ste: " + line);
            String[] splited = line.split(" ");
            int br = splited.length - 1;
            //System.out.println(br);
            switch (splited[0]) {

                case "quit":
                    return;
                case "newSt":
                    System.out.println("Init storage");
                    local.storageInit(splited[1], Integer.parseInt(splited[2]), splited[3]);
                    break;
                case "mkdir":
                    if (br==1)
                        local.createDirectory(splited[1]);
                    else
                        local.createDirectory(splited[1], Integer.parseInt(splited[2]));
                    System.out.println("Pravljenje dir-a");
                    break;

                case "touch":
                    local.createFile(splited[1]);
                    break;

                case "ls":
                    if (br == 0) {
                        ispis(local.listAll());
                    } else {
                        ispis(local.listAll(splited[1]));
                    }
                    break;

                case "lsFull":
                    ispis(local.listFull());
                    break;

                case "extls":
                    //ekstenzije se odvajaju zarezom
                    String[] ekstenzije = splited[1].split(",");
                    ispis(local.listExt(ekstenzije));
                    break;

                case "lsWith":
                    if (br == 0) {
                        ispis(local.listAll());
                    } else {
                        ispis(local.listFilesWith(splited[1]));
                    }
                    break;

                case "has":
                    String[] fajlovi = splited[2].split(",");
                    System.out.println((local.listContains(splited[1], fajlovi)));
                    break;

                case "find":
                    System.out.println(local.findDirecotry(splited[1]));
                    break;

                case "filter":
                    String[] split = splited[1].split(",");
                    local.fileInfoFilter(split);
                    break;

                case "rm":
                    local.deleteFile(splited[1]);
                    break;

                case "rmDir":
                    local.deleteDirectory(splited[1]);
                    break;
                case "rename":
                    local.renameFile(splited[1], splited[2]);
                    break;
                case "move":
                    local.moveFile(splited[1], splited[2]);
                    break;
                case "cd":
                    boolean frw;
                    if (splited[1].equalsIgnoreCase("..")) {
                        frw = local.backwards();
                    } else
                        frw = local.forward(splited[1]);
                    System.out.println(frw);
                    break;

                case "sort":
                    if (br==0){
                        ispis(local.sort("desc", "name"));
                    } else if (br==2)
                        ispis(local.sort(splited[1], splited[2]));
                    break;

                default:
                    System.out.println("Lose unesena komanda, probaj opet.");
            }
        }
    }
}
